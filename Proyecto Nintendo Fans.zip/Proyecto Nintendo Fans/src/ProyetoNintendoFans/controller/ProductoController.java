/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProyetoNintendoFans.controller;

import ProyectoNintendoFans.dao.ProductoDAO;
import ProyectoNintendoFans.model.Producto;
import java.sql.SQLException;
import java.util.List;
public class ProductoController {
private ProductoDAO productoDAO;
public ProductoController() {
this.productoDAO = new ProductoDAO();
}
public void guardarProducto(String nombre, double precio, int stock) throws SQLException {
Producto p = new Producto();
p.setNombre(nombre);
p.setPrecio(precio);
p.setStock(stock);
productoDAO.insertar(p);
}
public void actualizarProducto(int id, String nombre, double precio, int stock) throws SQLException {
Producto p = new Producto(id, nombre, precio, stock);
productoDAO.modificar(p);
}
public void eliminarProducto(int id) throws SQLException {
productoDAO.eliminar(id);
}
public Producto buscarProducto(int id) throws SQLException {
return productoDAO.buscarPorId(id);
}
public List<Producto> listarProductos() throws SQLException {
return productoDAO.listar();
}
}